# It's my homepage. It's [here](https://zhoukekestar.github.io/).
* [Best-Pokemon-to-Fight](https://zhoukekestar.github.io/Best-Pokemon-to-Fight/)
* [BDC-plan](https://zhoukekestar.github.io/BDC/)


# Todo
* update my homepage
  * What are you looking for ? Notes? Profile ? resume ? or just homepage ?
  * page is based on canvas ? webgl ? Game engine?
  * Background maybe a fluybird ? Control by Machine learning ?
  * Data visulize about github ? Contribute nubmer ? Projects ? Built by vue ? React ?
    * This page should be a single page packed by webpack or rollup and so on...


# notes
  * Fill the hole !
    * AJAX (anything left? See jquery api list!
    * rollup ? webpack ?
    * Server powered by leancould should proxy my ajax request!
    * MVC, MVVM?
    * Security & optimize ...https, http2, cache?
